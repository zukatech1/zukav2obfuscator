return (function(...) (function() return('scriptblox is a dogshit site') end)();
local __warn=(function()
    local _ok,_f=pcall(function()return warn end)
    return(_ok and type(_f)=="function")and _f or print
end)()
local Sub,Byte,Char,Find,Floor,Pairs,Insert,Pcall,ToNumber=string.sub,string.byte,string.char,string.find,math.floor,pairs,table.insert,pcall,tonumber;
local encrypted_table={[6]=print,[7]=__warn,[8]=error,[10]=function()end};
local decropress,decrypt,ARR,key1,key2,temp,key3,key4,GetPsewdo,key5,chars = nil,nil,nil,371.2,580,nil,510.4,266.8,nil,475.6,"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
if key1 then
if key2 then
if key3 then
if key4 then
local GlobalTable = {
  [371.2] = function()
	  decropress = function(str)
    	local result = ""
	for i = 1, #str, 2 do
		local c1 = Find(chars, Sub(str,i, i)) - 1
        local c2 = Find(chars, Sub(str,i + 1, i + 1)) - 1
		local byte = c1 * 4 + Floor(c2 / 16)
		result = result .. Char(byte)
	end
	return result
     end;
  end,
    [580] = function()
	 decrypt = function(str)
	local result = {}
	for i =1,#str do
		local char = Sub(str,i,i)
		local byte = Byte(char)
		local keys = GetPsewdo()
		local encrypted_byte = (byte -  172 - keys[1]-keys[2]- keys[3] - (i + 2)) % 256
		result[i] = Char(encrypted_byte)
	end
	return result
end
  end,
     [510.4] = function()
	if decropress then 
		if decrypt then
     temp = decropress('BQCQ/g/QCQvgBQFQDwBQFwDQFAFAxw/AAg7QFgGwBQEw/QFwJwHA2wGAGgLw+gIQBA+wFQ5Qxw3g3w4A4QNAKAOAOgOANQ6A8QLgMARQEANwGgEQKw8gEQEQ9QCgDw+AOgSAPw/AQQQwWAIwSgLQJAPgBQIgJACAHgIQFADAXAYADwGAVQVwbANwXgQQOAUgGQOAOAHAMwMwHwYQbwZgIwaAagfwSgcQVASwZQLASQSwLwSQQQOwMwgwhwNgPwfAfgkwXghQaAXweQQAXwXwQwXQXARgiAlgjQSgjwkQpgcQmAewcgjAUwcAcgVgaAagawYwRQoQqwogSQSgrQsQpgpQsQZgrQvQtwrQvwtQvAvAbwkQwQxAtQlQxwwgqAzA0AggvQnwtAxQ0wqgzAowuArgkQhguAuQsg1Q2QuguAsg6A1w1wmwfQlAlQlglw5A6A3Q3A6AnQygwQ6Q9wyg0w8w+A7w7Q9QqQxwqwBwCgmArwsAsQsg+QAwBwtgAAuA1gugzAyAvQwQAQ4w+ACQFw7gEA5w/A8gyQDgGgtgzQzgzw0A0Q0g0w1AIQJQGgGQJQ2gHwIQNgAQKACwAgHA4wAQ5QKACgHwMAPgFQNwDgIwGQCgMwSwRwOQ/QPwAA4g+Q+g+w/A/Q/g/wAASgSAAwOAPgKQUgVwQQTwOQUwYwWAFwVAVgawNgXQQANwUQIQGQbgYwYQawCAHwIAIQIgIwJAJQJgJwKAKQKgdwewcAbwewMAYwWAWAXQXgcAhAXAfwaAdAXgPQPgPwQAQQQgQwRARQRgRwSAkgkASwkAkgpwcgmQfAcwjQVAcwcwVwbAcQWgnAqgoQXgowpQughQrAjwhgoAZwhAhgaggAgwbQwgtwtQvwXAcwdAdQdgdweAeQegewfAfQfgfwgAgQggtQqgqgrwsAwg1grg0QugxgsAjwrQkQmgmw2A2g7wug4QxAuw1QnAqgngswuAoQrwow1Q1gzw8g9g1w1QzwBQ9A9ArwuwsQwwwwvQtQuwtwyQyQwwuwxwvQ0g1wqgwQwgwwxAxQxgxwyAyQygywzAEgGgIgFQGgGA0wGAGgLw+gIQBA+wFQ3A+w+w3w9g9g4gJAMgKQ5gKwLQQgDQNAFwDgKA7wDADg8gDABA9QSgPwPQRw5A+w/A/Q/g/wAAAQAgAwBABQBgBwCACQCgPQMgMgNwOASgXgNgWQQgTgOAFwNQGQIgIwYAYgdwQgaQTAQwXQJAMgJgPQPQKQNwKwXQXgVwegfgXwXQVwjQfAfANwQwOQTAUQRQPQQwPwUgVwSwQwTwRQXAXAMgSQSgSwTATQTgTwUAUQUgUwVAmgogqgnQogoAWwoAogtwggqQjAgwnQZAgwgwZwgQgAagrAugsQbgswtQyglQvAnwlgsAdwlAlgegjAjgjwfg0wyAxg0AbQhAhQhghwiAiQigiwjAjQjgjwkAkQkgkwxguwuwwAwQ0w5wvw4gyw1wwQoAvgogqwrA6Q6wAAyw8g1QzA5grQuwrwyQyAsgwAtA5g5w4AAwBw6A5g4AFgBQBQwAzAwg1Q2gzgxgzAyA2w4A1AzA2Azg6A5wuw0g0w1A1Q1g1w2A2Q2g2w3A3QIwLQJAyw4g4w5A5Q5g5w6A6Q6g6w7A7QQgMAMgPQNwAQPQQwSQPASgTQAgJwHgRgVAJwMAUAVQTASgUgEgBwWwXQXAVAWgVAHAUgWAUgZAGwRgOwOwQAQQUwZwPwYgSwVwQQKQKgDAIwJAJQJgJwKAKQKgcAeAgAcwGQMAMQMgMwNANQNgNwOAOQOgOwkAfggAiwhQTwiwkQlwigmAmwUAdQbAlAogdQfgngowmgmAoAYAVQqQqwqgogqAogagoApgoAsgaQpgqAvQiArwkgiQowcwdAVgbQbgbwcAcQcgcwdAugxAuwYgeQegewfAwgzAwwaggQgggwhA1wyw2w3Q2w2Aiw4Azg0A2w1Qnw1Q4g4g2A1w6woAxQvA5A8gxQzg7g8w6g6A8ArQjw6w9Q7AkwlA9w+w8A7w+wsAAQ2Q/A9g3AAQ8QEg/gpACw4wBgAA5gCw+wHACAxA4gxgFwGgEgGAHw5wtwHg9gGQEw+QHgDgLwGw3w+QKQLAHQ/QLwKgEANAOA6g5QLQKwMwNAOA6QQgOwPwOgMw8Q/A8QAw/A/Q');
		end;
	end;
  end,
  [266.8] = function()
	if decrypt then
	if decropress then 
     ARR = decrypt(temp);
	 end;
	end;
  end,
  [475.6] = function()
     GetPsewdo = function()
		local t1 = 147 * 2
	    local t2 = t1 + 41
	    local t3 = t1 + t2
	    return {t1,t2,t3}
	 end
  end,
};
if key1 then
GlobalTable[key5]();
if key2 then
GlobalTable[key1]();
if key3 then
GlobalTable[key2]();
if key4 then
if key5 then
GlobalTable[key3]();
end;
end;
end;
GlobalTable[key4]();
end;
end;
end;
end;
end;
end;
if ARR then
    local _src=table.concat(ARR)
    local _fn,_err=(loadstring or load)(_src)
    if _fn then _fn() else error("uwu cutie error: "..tostring(_err)) end
end
 end)(...)