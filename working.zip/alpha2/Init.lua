-- ╔══════════════════════════════════════════════════════════╗
-- ║              ZukaTech Obfuscator v2 - init.lua           ║
-- ╚══════════════════════════════════════════════════════════╝
package.path = "./?.lua;./Obfuscator/?.lua;./Obfuscator/Lua/?.lua;./Obfuscator/Lua/Minifier/?.lua;" .. package.path

-- ── Globals ──────────────────────────────────────────────────────────────────
config = {
    NameUpper   = "ZUKTECH",
    IdentPrefix = "__ZukaTech",
}

if not colors then
    colors = function(str, _color) return tostring(str) end
end

util = util or {}
function util.shuffle(t)
    for i = #t, 2, -1 do
        local j = math.random(1, i)
        t[i], t[j] = t[j], t[i]
    end
end

utils = utils or {}
function utils.chararray(str)
    local t = {}
    for i = 1, #str do t[i] = str:sub(i, i) end
    return t
end

-- ── Load modules ──────────────────────────────────────────────────────────────
local logger          = require("Obfuscator.logger")
local Minifier        = require("Obfuscator.Lua.Minifier.init")
local StringEncrypt   = require("Obfuscator.StringEncryption")
local StringEncoder   = require("Obfuscator.string_encoder")
local VariableRenamer = require("Obfuscator.variable_renamer")
local WrapInFunction  = require("Obfuscator.WrapInFunction")
local MemeString      = require("Obfuscator.MemeString")
local Watermark       = require("Obfuscator.Watermark")
local Hex             = require("Obfuscator.hex")
local VmifyBC         = require("Obfuscator.VmifyBC")
local Parser          = require("Obfuscator.Parser")
local Enums           = require("Obfuscator.enums")

-- ── Configuration ─────────────────────────────────────────────────────────────
local Options = {
    minify          = false,
    vmifybc         = false,   
    renameVariables = true,
    stringEncrypt   = true,
    stringEncryptV2 = true,
    wrapInFunction  = true,
    watermark       = false,
    antiTamper      = false,
    memeStrings     = false,
    memeCount       = 1,
    hexNames        = true,
    varNameMinLen   = 8,
    varNameMaxLen   = 14,
}

-- [FIX] Ensure these are defined before line 37
local inputPath  = "input.lua"
local outputPath = "output.lua"

-- ── I/O ───────────────────────────────────────────────────────────────────────
local fIn, err = io.open(inputPath, "r")
if not fIn then 
    error(string.format("[ZukaTech] Failed to open input file '%s': %s", tostring(inputPath), tostring(err))) 
end

local source = fIn:read("*a")
fIn:close()

if not source or #source == 0 then 
    error("[ZukaTech] Input file is empty or could not be read") 
end

logger:log("Loaded " .. #source .. " bytes from " .. inputPath)

-- ── PIPELINE ─────────────────────────────────────────────────────────────────

-- 1. Minify
if Options.minify then
    local ok, r = pcall(Minifier.optimize, Minifier.DEFAULT_OPTS, source)
    if ok and r and #r > 0 then
        source = r
        logger:log("Minified → " .. #source .. " bytes")
    else
        logger:warn("Minifier failed, skipping")
    end
end

-- 2. Rename variables / functions
if Options.renameVariables then
    local nameGen = nil
    if Options.hexNames then Hex.prepare(); nameGen = Hex end
    local ok, r = pcall(VariableRenamer.process, source, {
        min_length    = Options.varNameMinLen,
        max_length    = Options.varNameMaxLen,
        namegenerator = nameGen,
    })
    if ok and r and #r > 0 then
        source = r
        logger:log("Renamed vars → " .. #source .. " bytes")
    else
        logger:warn("VariableRenamer failed, skipping")
    end
end

-- 3. Caesar-cipher string literals
if Options.stringEncrypt then
    local ok, r = pcall(StringEncoder.process, source)
    if ok and r and #r > 0 then
        source = r
        logger:log("Caesar strings → " .. #source .. " bytes")
    else
        logger:warn("StringEncoder failed, skipping")
    end
end

-- 4. VmifyBC: Bytecode Virtualization
if Options.vmifybc then
    local ok, r = pcall(function()
        local parser = Parser:new({ luaVersion = Enums.LuaVersion.Lua51 })
        local ast = parser:parse(source)
        return VmifyBC:apply(ast) 
    end)
    
    if ok and r and type(r) == "string" then
        source = r
        logger:log("VmifyBC: Virtualized → " .. #source .. " bytes")
    else
        logger:warn("[VmifyBC] Virtualization failed or returned non-string: " .. tostring(r))
    end
end

-- 5. XOR/compress full source into self-decrypting loader
if Options.stringEncryptV2 then
    local ok, r = pcall(function()
        local warnSafe = [[local __warn=(function()
    local _ok,_f=pcall(function()return warn end)
    return(_ok and type(_f)=="function")and _f or print
end)()]]
        
        local stdlib = "local Sub,Byte,Char,Find,Floor,Pairs,Insert,Pcall,ToNumber=" ..
            "string.sub,string.byte,string.char,string.find," ..
            "math.floor,pairs,table.insert,pcall,tonumber;"
            
        local encTable = "local encrypted_table={[6]=print,[7]=__warn,[8]=error,[10]=function()end};"
        local encrypted   = StringEncrypt:Encrypt(source)
        local decodeBlock = StringEncrypt.AddDecodeCode(encrypted)
        
        local loader = [[
if ARR then
    local _src=table.concat(ARR)
    local _fn,_err=(loadstring or load)(_src)
    if _fn then _fn() else error("ZukaTech decrypt error: "..tostring(_err)) end
end
]]
        return warnSafe.."\n"..stdlib.."\n"..encTable.."\n"..decodeBlock..loader
    end)
    
    if ok and r and #r > 0 then
        source = r
        logger:log("EncryptV2 → " .. #source .. " bytes")
    else
        logger:warn("StringEncryptV2 failed, skipping")
    end
end

-- 6. Meme strings — OUTER SHELL
if Options.memeStrings then
    local memeBlock = ""
    if MemeString.GenerateMemeStrings then
        memeBlock = MemeString.GenerateMemeStrings(Options.memeCount)
    else
        local seen, out = {}, {}
        local tries = 0
        while #out < Options.memeCount and tries < 100 do
            local s = MemeString.GenerateMemeString()
            if not seen[s] then seen[s] = true; out[#out+1] = s end
            tries = tries + 1
        end
        memeBlock = table.concat(out, "\n")
    end
    source = memeBlock .. "\n" .. source
    logger:log("Meme strings injected")
end

-- 7. Watermark — OUTER SHELL
if Options.watermark and Watermark.Enabled then
    local mark = Watermark.WaterMarkAdd()
    if mark then
        source = mark .. "\n" .. source
        logger:log("Watermark injected")
    end
end

-- 8. Anti-tamper — OUTER SHELL
if Options.antiTamper then
    local ok, block = pcall(function() return AntiTamper:Apply() end)
    if ok and block then
        source = block .. "\n" .. source
        logger:log("Anti-tamper injected")
    else
        logger:warn("AntiTamper failed, skipping")
    end
end

-- 9. Wrap in function
if Options.wrapInFunction then
    source = WrapInFunction.process(source)
    logger:log("Wrapped in function")
end

-- ── Write ─────────────────────────────────────────────────────────────────────
local fOut, outErr = io.open(outputPath, "w")
if not fOut then 
    error(string.format("[ZukaTech] Cannot open output file '%s' for writing: %s", outputPath, tostring(outErr))) 
end

fOut:write(source)
fOut:close()

logger:log("Done → " .. outputPath .. " (" .. #source .. " bytes)")