local MIN_CHARACTERS = 5
local MAX_INITIAL_CHARACTERS = 10
local offset = 0
local function chararray(str)
    local t = {}
    for i = 1, #str do t[i] = str:sub(i, i) end
    return t
end
local VarDigits = chararray("Il1")
local VarStartDigits = chararray("Il")
local function generateName(id, scope)
    local name = ''
    id = id + offset
    local d = id % #VarStartDigits
    id = (id - d) / #VarStartDigits
    name = name..VarStartDigits[d+1]
    while id > 0 do
        local d = id % #VarDigits
        id = (id - d) / #VarDigits
        name = name..VarDigits[d+1]
    end
    return name
end
local function prepare(ast)
    if util and util.shuffle then
        util.shuffle(VarDigits)
        util.shuffle(VarStartDigits)
    end
    offset = math.random(math.pow(3, MIN_CHARACTERS), math.pow(3, MAX_INITIAL_CHARACTERS))
end
return {
    generateName = generateName, 
    prepare = prepare
}