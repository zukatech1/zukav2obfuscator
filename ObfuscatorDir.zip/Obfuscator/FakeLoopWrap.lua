-- ╔══════════════════════════════════════════════════════════╗
-- ║              ZukaTech Obfuscator - FakeLoopWrap          ║
-- ╚══════════════════════════════════════════════════════════╝
local Ast      = require("ast")
local Scope    = require("scope")
local AstKind  = Ast.AstKind

local visitast = require("visitast")

local FakeLoopWrap = {}
FakeLoopWrap.Description = "Wraps random statements in fake single-iteration while-true-break loops"
FakeLoopWrap.Name        = "Fake Loop Wrap"

-- Default settings
FakeLoopWrap.SettingsDescriptor = {
    Treshold = {
        type    = "number",
        default = 0.35,
        min     = 0,
        max     = 1,
    },
}

-- Constructor to handle the :new() call from init.lua
function FakeLoopWrap:new(settings)
    local obj = setmetatable({}, { __index = self })
    -- Ensure Treshold is set correctly from settings or default
    obj.Treshold = (settings and settings.Treshold) or 0.35
    return obj
end

-- Statement kinds that cannot be wrapped safely
local UNSAFE_WRAP = {
    [AstKind.ReturnStatement]   = true,
    [AstKind.BreakStatement]    = true,
    [AstKind.ContinueStatement] = true,
}

-- Statement kinds that introduce a real loop body
local REAL_LOOP_STMT = {
    [AstKind.WhileStatement]  = true,
    [AstKind.RepeatStatement] = true,
    [AstKind.ForStatement]    = true,
    [AstKind.ForInStatement]  = true,
}

function FakeLoopWrap:apply(ast)
    local treshold = self.Treshold or 0.35
    
    -- Using the correct case 'visitAst' imported above
    visitast(ast,
        -- previsit: tag real-loop body blocks so we skip them below
        function(node, data)
            if REAL_LOOP_STMT[node.kind] and node.body then
                node.body.__insideRealLoop = true
            end
        end,
        
        -- postvisit: wrap eligible statements after children are processed
        function(node, data)
            if node.kind ~= AstKind.Block then return end
            
            -- Never wrap inside a real loop's direct body to avoid breaking 'break'
            if node.__insideRealLoop then return end
            
            local i = 1
            while i <= #node.statements do
                local stmt = node.statements[i]
                
                -- Only wrap if it's safe and meets the random threshold
                if stmt and not UNSAFE_WRAP[stmt.kind] and math.random() <= treshold then
                    -- Create a new scope for the fake loop body
                    local loopScope = Scope:new(node.scope)
                    
                    -- Create the block containing the statement and a break
                    local loopBody = Ast.Block(
                        {
                            stmt,
                            Ast.BreakStatement(nil, loopScope),
                        },
                        loopScope
                    )
                    
                    -- Construct the while true do ... break end node
                    local whileNode = Ast.WhileStatement(
                        loopBody,
                        Ast.BooleanExpression(true),
                        node.scope
                    )
                    
                    -- Replace the original statement with our fake loop
                    node.statements[i] = whileNode
                end
                i = i + 1
            end
        end
    )
end

return FakeLoopWrap