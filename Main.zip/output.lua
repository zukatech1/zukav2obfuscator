return (function(...) (function() return('where the fuck is emi giovanna?') end)();
local __warn=(function()
    local _ok,_f=pcall(function()return warn end)
    return(_ok and type(_f)=="function")and _f or print
end)()
local Sub,Byte,Char,Find,Floor,Pairs,Insert,Pcall,ToNumber=string.sub,string.byte,string.char,string.find,math.floor,pairs,table.insert,pcall,tonumber;
local encrypted_table={[6]=print,[7]=__warn,[8]=error,[10]=function()end};
local decropress,decrypt,ARR,key1,key2,temp,key3,key4,GetPsewdo,key5,chars = nil,nil,nil,233.6,365,nil,321.2,167.9,nil,299.3,"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
if key1 then
if key2 then
if key3 then
if key4 then
local GlobalTable = {
  [233.6] = function()
	  decropress = function(str)
    	local result = ""
	for i = 1, #str, 2 do
		local c1 = Find(chars, Sub(str,i, i)) - 1
        local c2 = Find(chars, Sub(str,i + 1, i + 1)) - 1
		local byte = c1 * 4 + Floor(c2 / 16)
		result = result .. Char(byte)
	end
	return result
     end;
  end,
    [365] = function()
	 decrypt = function(str)
	local result = {}
	for i =1,#str do
		local char = Sub(str,i,i)
		local byte = Byte(char)
		local keys = GetPsewdo()
		local encrypted_byte = (byte -  189 - keys[1]-keys[2]- keys[3] - (i + 6)) % 256
		result[i] = Char(encrypted_byte)
	end
	return result
end
  end,
     [321.2] = function()
	if decropress then 
		if decrypt then
     temp = decropress('ggcAcgfQdwTQNARQjgRwSAewUgTwfgggTg');
		end;
	end;
  end,
  [167.9] = function()
	if decrypt then
	if decropress then 
     ARR = decrypt(temp);
	 end;
	end;
  end,
  [299.3] = function()
     GetPsewdo = function()
		local t1 = 831 * 2
	    local t2 = t1 + 41
	    local t3 = t1 + t2
	    return {t1,t2,t3}
	 end
  end,
};
if key1 then
GlobalTable[key5]();
if key2 then
GlobalTable[key1]();
if key3 then
GlobalTable[key2]();
if key4 then
if key5 then
GlobalTable[key3]();
end;
end;
end;
GlobalTable[key4]();
end;
end;
end;
end;
end;
end;
if ARR then
    local _src=table.concat(ARR)
    local _fn,_err=(loadstring or load)(_src)
    if _fn then _fn() else error("ZukaTech decrypt error: "..tostring(_err)) end
end
 end)(...)