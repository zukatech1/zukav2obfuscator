package.path = "./?.lua;./Obfuscator/?.lua;./Obfuscator/Lua/?.lua;./Obfuscator/Lua/Minifier/?.lua;" .. package.path
config = {
    NameUpper   = "ZUKTECH",
    IdentPrefix = "__ZukaTech",
}
if not colors then
    colors = function(str, _color) return tostring(str) end
end
util = util or {}
function util.shuffle(t)
    for i = #t, 2, -1 do
        local j = math.random(1, i)
        t[i], t[j] = t[j], t[i]
    end
end
utils = utils or {}
function utils.chararray(str)
    local t = {}
    for i = 1, #str do t[i] = str:sub(i, i) end
    return t
end
local BarcodeGen = (function()
    local MIN_CHARACTERS = 10
    local MAX_INITIAL_CHARACTERS = 15
    local offset = 0
    local VarDigits = utils.chararray("Il1")
    local VarStartDigits = utils.chararray("Il")
    local function generateName(id)
        local name = 'ilil'
        id = id + (offset or 0)
        local d = id % #VarStartDigits
        id = (id - d) / #VarStartDigits
        name = name .. VarStartDigits[d+1]
        while id > 0 do
            local d = id % #VarDigits
            id = (id - d) / #VarDigits
            name = name .. VarDigits[d+1]
        end
        return name
    end
    local function prepare()
        util.shuffle(VarDigits)
        util.shuffle(VarStartDigits)
        offset = math.random(math.pow(3, MIN_CHARACTERS), math.pow(3, MAX_INITIAL_CHARACTERS))
    end
    return {
        generateName = generateName,
        prepare = prepare
    }
end)()
local logger          = require("Obfuscator.logger")
local Minifier        = require("Obfuscator.Lua.Minifier.init")
local StringEncrypt   = require("Obfuscator.StringEncryption")
local StringEncoder   = require("Obfuscator.string_encoder")
local VariableRenamer = require("Obfuscator.variable_renamer")
local WrapInFunction  = require("Obfuscator.WrapInFunction")
local MemeString      = require("Obfuscator.MemeString")
local ast             = require("Obfuscator.ast")
local Watermark       = require("Obfuscator.Watermark")
local Hex             = require("Obfuscator.hex")
local Il              = require("Obfuscator.il")
local VmifyBC         = require("Obfuscator.VmifyBC")
local Parser          = require("Obfuscator.Parser")
local Enums           = require("Obfuscator.enums")
local Options = {
    minify             = false,
    vmifybc            = false,
    renameVariables    = true,
    stringEncrypt      = false,
    stringEncryptV2    = true,
    wrapInFunction     = true,
    watermark          = false,
    antiTamper         = false,
    memeStrings        = true,
    memeCount          = 1,
    hexNames           = true,
    Il                 = false,
    varNameMinLen      = 8,
    varNameMaxLen      = 14,
    fakeLoopWrap       = true,
    numbersToExprs     = true,
    opaquePredicates   = true,
    fakeLoopTreshold   = 0.35,
    numExprTreshold    = 1.0,
    numExprInternal    = 0.2,
    opaqueTreshold     = 1,
    opaquePerBlock     = 2,
}
local inputPath  = "input.lua"
local outputPath = "output.lua"
local fIn, err = io.open(inputPath, "r")
if not fIn then
    error(string.format("[ZukaTech] Failed to open input file '%s': %s", tostring(inputPath), tostring(err)))
end
local source = fIn:read("*a")
fIn:close()
if not source or #source == 0 then
    error("[ZukaTech] Input file is empty or could not be read")
end
logger:log("Loaded " .. #source .. " bytes from " .. inputPath)
if Options.minify then
    local ok, r = pcall(Minifier.optimize, Minifier.DEFAULT_OPTS, source)
    if ok and r and #r > 0 then
        source = r
        logger:log("Minified → " .. #source .. " bytes")
    else
        logger:warn("Minifier failed, skipping")
    end
end
if Options.renameVariables then
    local nameGen = Hex
    if Options.Il then
        Il.prepare()
        nameGen = Il
    elseif Options.hexNames then
        Hex.prepare()
        nameGen = Hex
    end
    local ok, r = pcall(VariableRenamer.process, source, {
        min_length    = Options.varNameMinLen,
        max_length    = Options.varNameMaxLen,
        namegenerator = nameGen,
    })
    if ok and r and #r > 0 then
        source = r
        logger:log("Renamed vars → " .. #source .. " bytes")
    else
        logger:warn("VariableRenamer failed, skipping: " .. tostring(r))
    end
end
if Options.stringEncrypt then
    local ok, r = pcall(StringEncoder.process, source)
    if ok and r and #r > 0 then
        source = r
        logger:log("Caesar strings → " .. #source .. " bytes")
    else
        logger:warn("StringEncoder failed, skipping")
    end
end
if Options.fakeLoopWrap or Options.numbersToExprs or Options.opaquePredicates or Options.vmifybc then
    local ok, r = pcall(function()
        local FakeLoopWrap, NumbersToExpressions, OpaquePredicates
        if Options.fakeLoopWrap then
            local ok2, m = pcall(require, "Obfuscator.FakeLoopWrap")
            if ok2 then FakeLoopWrap = m else logger:warn("FakeLoopWrap load failed: " .. tostring(m)) end
        end
        if Options.numbersToExprs then
            local ok2, m = pcall(require, "Obfuscator.NumbersToExpressions")
            if ok2 then NumbersToExpressions = m else logger:warn("NumbersToExpressions load failed: " .. tostring(m)) end
        end
        if Options.opaquePredicates then
            local ok2, m = pcall(require, "Obfuscator.OpaquePredicates")
            if ok2 then OpaquePredicates = m else logger:warn("OpaquePredicates load failed: " .. tostring(m)) end
        end
        local parser = Parser:new({ luaVersion = Enums.LuaVersion.Lua51 })
        local ast    = parser:parse(source)
if FakeLoopWrap then
    if type(FakeLoopWrap.new) == "function" then
        local step = FakeLoopWrap:new({ Treshold = Options.fakeLoopTreshold or 0.5 })
        if step.apply then
            step:apply(ast)
            logger:log("FakeLoopWrap applied")
        end
    elseif type(FakeLoopWrap.apply) == "function" then
        FakeLoopWrap:apply(ast, { Treshold = Options.fakeLoopTreshold or 0.5 })
        logger:log("FakeLoopWrap applied (direct)")
    else
        logger:warn("FakeLoopWrap module found but no 'new' or 'apply' method exists.")
    end
end
if NumbersToExpressions and type(NumbersToExpressions.new) == "function" then
    local step = NumbersToExpressions:new({
        Treshold         = Options.numExprTreshold or 0.5,
        InternalTreshold = Options.numExprInternal or 0.5,
    })
    step:apply(ast)
    logger:log("NumbersToExpressions applied")
end
if OpaquePredicates and type(OpaquePredicates.new) == "function" then
    local step = OpaquePredicates:new({
        Treshold           = Options.opaqueTreshold or 0.5,
        InjectionsPerBlock = Options.opaquePerBlock or 1,
    })
    step:apply(ast, nil)
    logger:log("OpaquePredicates applied")
end
        if Options.vmifybc then
            local result = VmifyBC:apply(ast)
            if type(result) == "string" then
                return result
            end
        end
        return tostring(ast)
    end)
    if ok and r and type(r) == "string" and #r > 0 then
        source = r
        logger:log("AST pipeline done → " .. #source .. " bytes")
    else
        logger:warn("AST pipeline failed: " .. tostring(r))
    end
end
if Options.stringEncryptV2 then
    local ok, r = pcall(function()
        local warnSafe = [[local __warn=(function()
    local _ok,_f=pcall(function()return warn end)
    return(_ok and type(_f)=="function")and _f or print
end)()]]
        local stdlib = "local Sub,Byte,Char,Find,Floor,Pairs,Insert,Pcall,ToNumber=" ..
            "string.sub,string.byte,string.char,string.find," ..
            "math.floor,pairs,table.insert,pcall,tonumber;"
        local encTable = "local encrypted_table={[6]=print,[7]=__warn,[8]=error,[10]=function()end};"
        local encrypted   = StringEncrypt:Encrypt(source)
        local decodeBlock = StringEncrypt.AddDecodeCode(encrypted)
        local loader = [[
if ARR then
    local _src=table.concat(ARR)
    local _fn,_err=(loadstring or load)(_src)
    if _fn then _fn() else error("ZukaTech decrypt error: "..tostring(_err)) end
end
]]
        return warnSafe.."\n"..stdlib.."\n"..encTable.."\n"..decodeBlock..loader
    end)
    if ok and r and #r > 0 then
        source = r
        logger:log("EncryptV2 → " .. #source .. " bytes")
    else
        logger:warn("StringEncryptV2 failed, skipping")
    end
end
if Options.memeStrings then
    local memeBlock = ""
    if MemeString.GenerateMemeStrings then
        memeBlock = MemeString.GenerateMemeStrings(Options.memeCount)
    else
        local seen, out = {}, {}
        local tries = 0
        while #out < Options.memeCount and tries < 100 do
            local s = MemeString.GenerateMemeString()
            if not seen[s] then seen[s] = true; out[#out+1] = s end
            tries = tries + 1
        end
        memeBlock = table.concat(out, "\n")
    end
    source = memeBlock .. "\n" .. source
    logger:log("Meme strings injected")
end
if Options.watermark and Watermark.Enabled then
    local mark = Watermark.WaterMarkAdd()
    if mark then
        source = mark .. "\n" .. source
        logger:log("Watermark injected")
    end
end
if Options.antiTamper then
    local ok, block = pcall(function() return AntiTamper:Apply() end)
    if ok and block then
        source = block .. "\n" .. source
        logger:log("Anti-tamper injected")
    else
        logger:warn("AntiTamper failed, skipping")
    end
end
if Options.wrapInFunction then
    source = WrapInFunction.process(source)
    logger:log("Wrapped in function")
end
local fOut, outErr = io.open(outputPath, "w")
if not fOut then
    error(string.format("[ZukaTech] Cannot open output file '%s' for writing: %s", outputPath, tostring(outErr)))
end
fOut:write(source)
fOut:close()
logger:log("Done → " .. outputPath .. " (" .. #source .. " bytes)")